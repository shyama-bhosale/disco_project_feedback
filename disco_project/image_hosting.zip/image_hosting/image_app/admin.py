from django.contrib import admin

# Register your models here.

from django.contrib import admin
from image_app.models import Image

admin.site.register(Image)



